# Batch 192

Assignment 6 - Online shopping site + jQuery

First page: index.html

jQuery used in:
- index.html
- register.html
- return.html

Can be viewed at https://batch192.netlify.app/6/proj1/index.html